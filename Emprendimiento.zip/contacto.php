<section class="content-section bg-light" id="contact">
  <div class="container px-4 px-lg-5">
 <h2>Información de contacto</h2>
  <div class="form-group">
  <form method="post" action="index.php"
    <input type="text" name="nombre" class="form-control">
    <input type="email" name="correo" class="form-control">
     <textarea name="mensaje" class="form-conrol" cols="3", rows="10">

     </textarea>
     <button type="submit" class ="btn btn-ligth">Enviar</button>
     <button type="submit" class ="btn btn-ligth">Cancelar</button>
    


  <div>
    <div class="h2">Puntaje</div>
    <p class="mb-0">
      <center>98 % una calificación de 5 estrellas </center>
     <center> 2 % una calificicación de 4 estrellas</center>
       <center> Para un porcentaje de 100% </center>
</section>
 </div>