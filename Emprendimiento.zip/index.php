<!DOCTYPE html>
<html lang="en">
    <? include 'head.php' ?>
    <body id="page-top">
        <!-- Navigation-->
        <? include 'menu.php' ?>
        <!-- Header-->
        <header class="masthead d-flex align-items-center">
            <div class="container px-4 px-lg-5 text-center">

        
              
      
<h1 class="mb-1">DÉLICES DU CHOCOLAT</h1>
          
              
              
<h3 class="mb-5"><em>Una experiencia dulce</em></h3>
                <a class="btn btn-primary btn-xl" href="#proyecto">Acerca</a>
            </div>
        </header>
        <!-- About-->
        <?include 'acerca.php'?>
        <!-- Services-->
        <?include 'productos.php'?>
        <!-- Callout-->
        <section class="callout">
            <div class="container px-4 px-lg-5 text-center">
                <h2 class="mx-auto mb-5">
                    
                </h2>
                
            </div>
        </section>
        <!-- Proyecto -->
         <?include 'proyecto.php'?>
        <!-- contacto-->
        <? include 'contacto.php'?>
        <!-- Footer-->
        <footer class="footer text-center">
            <div class="container px-4 px-lg-5">
                <ul class="list-inline mb-5">
                    <li class="list-inline-item">
                        <div class="col-lg-3 col-md-6 mb-5 mb-md-0">
                          
     <img width="230" height="230" src="assets/img/CodigoQr.jpg" alt="..."/>
                        </ul>
                <p class="text-muted small mb-0">Copyright &copy; Your Website 2023</p>
            </div>
        </footer>
        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top"><i class="fas fa-angle-up"></i></a>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
    </body>
</html>
