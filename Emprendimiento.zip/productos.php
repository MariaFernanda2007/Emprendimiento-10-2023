 <section class="content-section bg-primary text-white text-center" id="productos">
            <div class="container px-4 px-lg-5">
                <div class="content-section-heading">
                    <h3 class="text-secondary mb-0">Productos</h3>
                    <h2 class="mb-5">Productos de venta</h2>
                </div>
                <div class="row gx-4 gx-lg-5">
                    <div class="col-lg-3 col-md-6 mb-5 mb-lg-0">
                        <span class="service-icon rounded-circle mx-auto mb-3"><i class=<"material-icons">🍪</i></span>
                        <h4><strong>Producto 1</strong></h4>
                        <p class="text-faded mb-0">Topins de frutas bañadas en chocolate</p>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-5 mb-lg-0">
                        <span class="service-icon rounded-circle mx-auto mb-3"><i class=<"material-icons">🍫</i></span>
                        <h4><strong>Producto 2</strong></h4>
                        <p class="text-faded mb-0">Marshmellos en chocolate</p>
                    </div>
                    <div class="col-lg-3 col-md-6 mb-5 mb-md-0">
                        <span class="service-icon rounded-circle mx-auto mb-3"><i class=<"material-icons">🍎🍫</i></span>
                        <h4><strong>Producto 3</strong></h4>
                        <p class="text-faded mb-0">
                            Frutas con chocolates
                           
                                                  </p>
                    </div>
                
                </div>
            </div>
        </section>