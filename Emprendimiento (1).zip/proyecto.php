<section class="content-section" id="proyecto">
            <div class="container px-4 px-lg-5">
                <div class="content-section-heading text-center">
                    <h2 class="mb-5">DÉLICES DU CHOCOLAT</h2>
                </div>
                <div class="row gx-0">
                    <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2">
                                     Objetivo general del sistema:</div>
                                    <p class="mb-0">Lograr que de forma más saludable abunde el chocolate y satisfacer los gustos que este produce.</p>
                                </div>
                            </div>
                            <img class="img-fluid" src="assets/img/Late3.jpg" alt="..." />
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2">Justificación</div>
                                    <p class="mb-0">Demostrar que el dulce en este caso el chocolate no es malo para la salud,ya que puede variar.</p>
                                </div>
                            </div>
                          
                            <img class="img-fluid" src="assets/img/Late1.jpg" alt="..." />
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2">Misión</div>
                                    <p class="mb-0">
Buscamos un crecimiento constante y sostenible en nuestro negocio. Esto implica la expansión de nuestras operaciones, la diversificación de nuestra oferta de productos y la optimización de nuestros procesos. 
                                  
                                    </p>
                                </div>
                            </div>
                            <img class="img-fluid" src="assets/img/portfolio-3.jpg" alt="..." />
                        </a>
                    </div>
                    <div class="col-lg-6">
                        <a class="portfolio-item" href="#!">
                            <div class="caption">
                                <div class="caption-content">
                                    <div class="h2">Visión</div>
                                    <p class="mb-0">
                                     La satisfacción de nuestros clientes es nuestra prioridad número uno. Estamos comprometidos a escuchar sus comentarios, atender sus necesidades y garantizar que cada experiencia con nuestros chocolates sea excepcional.
                                    
                                    </p>
                                  
                                </div>
                            </div>
                            <img class="img-fluid" src="assets/img/Late3.jpg" alt="..."/>
                        </a>
                    </div>
                </div>
            </div>
        </section>
        