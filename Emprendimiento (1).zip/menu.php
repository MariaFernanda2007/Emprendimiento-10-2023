        <a class="menu-toggle rounded" href="#"><i class="fas fa-bars"></i></a>
        <nav id="sidebar-wrapper">
            <ul class="sidebar-nav">
                <li class="sidebar-brand"><a href="#page-top">DÉLICES DU CHOCOLAT</a></li>
                <li class="sidebar-nav-item"><a href="#page-top">Home</a></li>
                <li class="sidebar-nav-item"><a href="#acerca">Acerca</a></li>
                <li class="sidebar-nav-item"><a href="#productos">Productos</a></li>
                <li class="sidebar-nav-item"><a href="#proyecto">Proyecto</a></li>
                <li class="sidebar-nav-item"><a href="#contacto">Contacto</a></li>
              <li class="sidebar-nav-item"><a href="DDC.zip">Prototipo</a></li>
            </ul>
        </nav>