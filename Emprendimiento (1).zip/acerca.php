<section class="content-section bg-light" id="acerca">
            <div class="container px-4 px-lg-5 text-center">
                <div class="row gx-4 gx-lg-5 justify-content-center">
                    <div class="col-lg-10">
                        <h2>DÉLICES DU CHOCOLAT es un proyecto de emprendimiento</h2>
                        <p class="lead mb-5">
                          Grado 10 de la IE Fe y Alegria Aures.
                          <br> Sus integrantes:
                          <br> Maria Fernanda Arroyave M.
                          <br> Daniel David Hernandez B.
                          <br> Jean Kevin Marin.
                          <br> Samuel Perez M.
                          <br> Juan Felipe Quiros B.
                          <br> Maria Isabel Romero A.
                        </p>
                        <a class="btn btn-dark btn-xl" href="#productos">Nuestros productos</a>
                    </div>
                
                </div>
            </div>
        </section>